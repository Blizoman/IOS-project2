#ifndef CLEANER_H
#define CLEANER_H

#include "_globals.h"

// Cleans up shared resources: semaphores, output file, and shared memory
void cleaner();

#endif //CLEANER_H